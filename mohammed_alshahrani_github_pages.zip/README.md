# بورتفوليو مهندس الصوت: محمد حاتم الشهراني | Sound Engineer Portfolio
- **الاسم / Name:** محمد حاتم الشهراني (Mohammed Hatem Al-Shahrani)
- **الرقم الجامعي / University ID:** 2441068
- **رقم الشعبة / Section:** 11-12
- **الجامعة والتخصص:** جامعة الملك عبدالعزيز – بكالوريوس إعلام (تخصص إنتاج مرئي ومسموع)

## طريقة نشر الموقع على GitHub Pages ليظهر للجميع برابط مباشر:
1. فك الضغط عن ملف `mohammed_alshahrani_github_pages.zip` على جهازك.
2. ادخل إلى حسابك في موقع [GitHub](https://github.com) واضغط على **New Repository** لإنشاء مستودع جديد (مثلاً باسم `portfolio`) واجعله **Public** ثم اضغط **Create repository**.
3. اضغط على **uploading an existing file**، ثم اسحب ملف `index.html` ومجلد `assets` بالكامل وارفعها، ثم اضغط **Commit changes**.
4. من أعلى صفحة المستودع، ادخل إلى **Settings** ثم من القائمة الجانبية اختر **Pages**.
5. تحت خيار **Branch**، اختر `main` بدلاً من `None` ثم اضغط **Save**.
6. خلال دقيقة واحدة سيظهر لك رابط موقعك الرسمي الجاهز للمشاركة مع أي شخص!
